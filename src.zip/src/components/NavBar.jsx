import Image from "next/image";
import React from "react";
import logoNavbar from "../assets/logoNavbar.png";
import Link from "next/link";

export default function NavBar() {
  const date = new Date();

  const formattedDate = date.toLocaleDateString("id-ID", {
    day: "numeric",
    month: "long",
    year: "numeric",
    weekday: "long",
    hour: "numeric",
    minute: "numeric",
  });

  return (
    <div className="flex bg-white px-14 py-6 justify-between items-center">
      <Image
        src={logoNavbar}
        alt="Logo"
        width="auto"
        className="w-32 h-11 object-cover"
      />
      <div className="">
        <ul className="flex gap-10 justify-center">
          <Link href="/">Beranda</Link>
          <Link href="/">
            Helpdesk <span>icon</span>
          </Link>
          <Link href="/formulir">Formulir</Link>
          <Link href="/document">Dokumen</Link>
          <Link href="/contact-us">Hubungi Kami</Link>
          <Link href="/faq">FAQ</Link>
        </ul>
      </div>
      <div>
        <p>{formattedDate + " WIB"}</p>
      </div>
    </div>
  );
}
