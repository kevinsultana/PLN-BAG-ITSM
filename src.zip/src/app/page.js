import HeroImg from "@/components/Home/HeroImg";
import NavBar from "@/components/NavBar";
import React from "react";

export default function page() {
  return (
    <div className="bg-slate-100 h-screen">
      <NavBar />
      <HeroImg />
    </div>
  );
}
