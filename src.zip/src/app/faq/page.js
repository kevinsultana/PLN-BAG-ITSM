import React from "react";

export default function faq() {
  return <div>faq</div>;
}
